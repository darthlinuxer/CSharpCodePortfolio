# Changelog
Running changelog of releases since `2.0.0`

## v2.0.0

### Features

- Updated Signin Widget version (5.2.0)
