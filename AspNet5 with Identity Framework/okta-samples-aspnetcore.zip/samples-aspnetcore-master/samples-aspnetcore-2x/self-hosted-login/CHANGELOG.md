# Changelog
Running changelog of releases since `2.0.0`

## v2.0.1

### Features

- Updated appsettings.json to include the Authorization Server ID placeholder.


## v2.0.0

### Features

- Updated Signin Widget version (5.2.0)
